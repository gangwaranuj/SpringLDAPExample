package com.thinksys.ldap.util;

public interface Constants {
	
	int ERROR_CODE_UNKNOWN = 520;
	int ERROR_CODE_INVALID = 206;
	int SUCCESS_CODE = 200;
	String SUCCESS = "Success";
	String ERROR = "ERROR";

}