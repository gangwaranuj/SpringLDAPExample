package com.thinksys.ldap.dao;

public interface LdapDao {
	
	public int changePasswordDao(String oldPassword,  String newPassword,String username);

}
