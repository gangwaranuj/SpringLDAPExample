package com.thinksys.ldap.daoImpl;

import java.io.IOException;
import java.net.URISyntaxException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.thinksys.ldap.bean.LdapConfigurationBean;
import com.thinksys.ldap.dao.AdminDao;
import com.thinksys.ldap.util.Response;
import com.thinksys.ldap.util.Utility;

@Repository
public class AdminDaoImpl implements AdminDao {

	private Logger logger = LoggerFactory.getLogger(AdminDaoImpl.class);
	@Override
	public Response setproperties(LdapConfigurationBean property) throws URISyntaxException, IOException {

		Response response=new Response();
		int result= Utility.setldapProperties(property.getLdap_url(), property.getLdap_managerdn(), property.getLdap_managerpassword(), property.getLdap_basesearch(), property.getLdap_groupsearch());	
		if(result>0)
		{   
			logger.info("AdminDaoImpl ::"+"property file is updated with !!"+property.toString());
			response.setStatus(true);
		}
		else{
			response.setStatus(false);
		}
		return response;

	}





}
